#!/usr/bin/env python
# -*- coding: UTF-8 -*-

'''
Module
    coap_server.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PKG} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PKG} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines server for CoAP service.
'''

import sys

try:
    from coapthon.server.coap import CoAP
    from basic_resources import BasicResource
except ImportError as ats_error_message:  # pragma: no cover
    # Force exit python #######################################################
    sys.exit(f'\n{__file__}\n{ats_error_message}\n')  # pragma: no cover


class CoAPServer(CoAP):
    '''
        Defines class CoAPServer with attribute(s) and method(s).
        Adds CoAP resource to server.

        It Definess:

            :attributes:
                | None
            :methods:
                | __init__ - Initials CoAPServer constructor.
    '''

    def __init__(self, host, port):
        '''
            Initials CoAPServer constructor.

            :param verbose: Enable/Disable verbose option
            :type verbose: <bool>
            :exceptions: None
        '''
        CoAP.__init__(self, (host, port))
        self.add_resource('basic/', BasicResource())


if __name__ == '__main__':
    server = CoAPServer('127.0.0.1', 5683)
    try:
        server.listen(10)
    except KeyboardInterrupt:
        print('Server Shutdown')
        server.close()
        print('Exiting...')
